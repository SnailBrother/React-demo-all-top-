export { default as Home } from './home';
export { default as About } from './about';
export { default as Login } from './user/login';
export { default as Register } from './user/register';